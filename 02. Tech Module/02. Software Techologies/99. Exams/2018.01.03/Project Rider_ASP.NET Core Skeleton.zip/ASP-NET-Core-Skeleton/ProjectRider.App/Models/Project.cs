﻿namespace ProjectRider.App.Models
{
    using System.ComponentModel.DataAnnotations;

    public class Project
    {
        //TODO: Implement me ...
    }
}
