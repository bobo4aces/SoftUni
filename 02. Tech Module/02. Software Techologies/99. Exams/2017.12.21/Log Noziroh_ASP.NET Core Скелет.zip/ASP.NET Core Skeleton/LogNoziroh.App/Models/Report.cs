﻿namespace LogNoziroh.App.Models
{
    using System.ComponentModel.DataAnnotations;

    public class Report
    {
        //TODO: Implement me ...
    }
}