<?php

/* base.html.twig */
class __TwigTemplate_4bbe4cb00ce6f8d465c8dd6727bc2b9ec28634a7580dd9013cb65806d5629e1e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body_id' => array($this, 'block_body_id'),
            'header' => array($this, 'block_header'),
            'body' => array($this, 'block_body'),
            'main' => array($this, 'block_main'),
            'footer' => array($this, 'block_footer'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d45f808abd5b76c25372a1c7ae02476004100af4d900cfe250fc77ad5aa42f7a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d45f808abd5b76c25372a1c7ae02476004100af4d900cfe250fc77ad5aa42f7a->enter($__internal_d45f808abd5b76c25372a1c7ae02476004100af4d900cfe250fc77ad5aa42f7a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        $__internal_a1244d9b4f30d70df6c02a3ca6a5868f017794974d7888102bfe003aa44cecc0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a1244d9b4f30d70df6c02a3ca6a5868f017794974d7888102bfe003aa44cecc0->enter($__internal_a1244d9b4f30d70df6c02a3ca6a5868f017794974d7888102bfe003aa44cecc0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 6
        echo "<!DOCTYPE html>
<html lang=\"en-US\">
<head>
    <meta charset=\"UTF-8\"/>
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\"/>
    <title>";
        // line 11
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
    ";
        // line 12
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 16
        echo "    <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\"/>
</head>

<body id=\"";
        // line 19
        $this->displayBlock('body_id', $context, $blocks);
        echo "\">

";
        // line 21
        $this->displayBlock('header', $context, $blocks);
        // line 39
        echo "
<div class=\"container body-container\">
    ";
        // line 41
        $this->displayBlock('body', $context, $blocks);
        // line 48
        echo "</div>

";
        // line 50
        $this->displayBlock('footer', $context, $blocks);
        // line 57
        echo "
";
        // line 58
        $this->displayBlock('javascripts', $context, $blocks);
        // line 64
        echo "
</body>
</html>
";
        
        $__internal_d45f808abd5b76c25372a1c7ae02476004100af4d900cfe250fc77ad5aa42f7a->leave($__internal_d45f808abd5b76c25372a1c7ae02476004100af4d900cfe250fc77ad5aa42f7a_prof);

        
        $__internal_a1244d9b4f30d70df6c02a3ca6a5868f017794974d7888102bfe003aa44cecc0->leave($__internal_a1244d9b4f30d70df6c02a3ca6a5868f017794974d7888102bfe003aa44cecc0_prof);

    }

    // line 11
    public function block_title($context, array $blocks = array())
    {
        $__internal_8657375a0c7ff54ebb0e031d6c76e63ad6f195e0a9a7f9d7f674a5639740652a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8657375a0c7ff54ebb0e031d6c76e63ad6f195e0a9a7f9d7f674a5639740652a->enter($__internal_8657375a0c7ff54ebb0e031d6c76e63ad6f195e0a9a7f9d7f674a5639740652a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_29bce544f1487b90b99dfa98f4afabb51a850a8381946830886ac811f335b8b0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_29bce544f1487b90b99dfa98f4afabb51a850a8381946830886ac811f335b8b0->enter($__internal_29bce544f1487b90b99dfa98f4afabb51a850a8381946830886ac811f335b8b0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Calculator";
        
        $__internal_29bce544f1487b90b99dfa98f4afabb51a850a8381946830886ac811f335b8b0->leave($__internal_29bce544f1487b90b99dfa98f4afabb51a850a8381946830886ac811f335b8b0_prof);

        
        $__internal_8657375a0c7ff54ebb0e031d6c76e63ad6f195e0a9a7f9d7f674a5639740652a->leave($__internal_8657375a0c7ff54ebb0e031d6c76e63ad6f195e0a9a7f9d7f674a5639740652a_prof);

    }

    // line 12
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_39d3fd39172e11bdef22e2182fbcf80183040e1fa3f6713c40a0ca89b4ccd680 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_39d3fd39172e11bdef22e2182fbcf80183040e1fa3f6713c40a0ca89b4ccd680->enter($__internal_39d3fd39172e11bdef22e2182fbcf80183040e1fa3f6713c40a0ca89b4ccd680_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_0bbae12c17034ac8ed94c51e521206cc54bf46bc9cd0b1890e7c310527108ae9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0bbae12c17034ac8ed94c51e521206cc54bf46bc9cd0b1890e7c310527108ae9->enter($__internal_0bbae12c17034ac8ed94c51e521206cc54bf46bc9cd0b1890e7c310527108ae9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 13
        echo "        <link rel=\"stylesheet\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/style.css"), "html", null, true);
        echo "\">
        <link rel=\"stylesheet\" href=\"";
        // line 14
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/bootstrap-datetimepicker.min.css"), "html", null, true);
        echo "\">
    ";
        
        $__internal_0bbae12c17034ac8ed94c51e521206cc54bf46bc9cd0b1890e7c310527108ae9->leave($__internal_0bbae12c17034ac8ed94c51e521206cc54bf46bc9cd0b1890e7c310527108ae9_prof);

        
        $__internal_39d3fd39172e11bdef22e2182fbcf80183040e1fa3f6713c40a0ca89b4ccd680->leave($__internal_39d3fd39172e11bdef22e2182fbcf80183040e1fa3f6713c40a0ca89b4ccd680_prof);

    }

    // line 19
    public function block_body_id($context, array $blocks = array())
    {
        $__internal_9243855c227c41650e15d30191e5a790c732ba43e537f63f1a1418d855a48b9a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9243855c227c41650e15d30191e5a790c732ba43e537f63f1a1418d855a48b9a->enter($__internal_9243855c227c41650e15d30191e5a790c732ba43e537f63f1a1418d855a48b9a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        $__internal_8ea7018f45df4f09c573acfd7fac063801ad221aceeaa7d5d21740f50cae259d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8ea7018f45df4f09c573acfd7fac063801ad221aceeaa7d5d21740f50cae259d->enter($__internal_8ea7018f45df4f09c573acfd7fac063801ad221aceeaa7d5d21740f50cae259d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        
        $__internal_8ea7018f45df4f09c573acfd7fac063801ad221aceeaa7d5d21740f50cae259d->leave($__internal_8ea7018f45df4f09c573acfd7fac063801ad221aceeaa7d5d21740f50cae259d_prof);

        
        $__internal_9243855c227c41650e15d30191e5a790c732ba43e537f63f1a1418d855a48b9a->leave($__internal_9243855c227c41650e15d30191e5a790c732ba43e537f63f1a1418d855a48b9a_prof);

    }

    // line 21
    public function block_header($context, array $blocks = array())
    {
        $__internal_06b44d56a7cb7cdf0645ed330e77f79a9175a1b8af018c1768b19e71a664c9d1 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_06b44d56a7cb7cdf0645ed330e77f79a9175a1b8af018c1768b19e71a664c9d1->enter($__internal_06b44d56a7cb7cdf0645ed330e77f79a9175a1b8af018c1768b19e71a664c9d1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "header"));

        $__internal_da7ca972a52175a3f05966551909561028d63cb0f8d13034446d190825541511 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_da7ca972a52175a3f05966551909561028d63cb0f8d13034446d190825541511->enter($__internal_da7ca972a52175a3f05966551909561028d63cb0f8d13034446d190825541511_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "header"));

        // line 22
        echo "    <header>
        <div class=\"navbar navbar-default navbar-static-top\" role=\"navigation\">
            <div class=\"container\">
                <div class=\"navbar-header\">
                    <a href=\"";
        // line 26
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("index");
        echo "\" class=\"navbar-brand\">CALCULATOR</a>

                    <button type=\"button\" class=\"navbar-toggle\" data-toggle=\"collapse\" data-target=\".navbar-collapse\">
                        <span class=\"icon-bar\"></span>
                        <span class=\"icon-bar\"></span>
                        <span class=\"icon-bar\"></span>
                    </button>
                </div>

            </div>
        </div>
    </header>
";
        
        $__internal_da7ca972a52175a3f05966551909561028d63cb0f8d13034446d190825541511->leave($__internal_da7ca972a52175a3f05966551909561028d63cb0f8d13034446d190825541511_prof);

        
        $__internal_06b44d56a7cb7cdf0645ed330e77f79a9175a1b8af018c1768b19e71a664c9d1->leave($__internal_06b44d56a7cb7cdf0645ed330e77f79a9175a1b8af018c1768b19e71a664c9d1_prof);

    }

    // line 41
    public function block_body($context, array $blocks = array())
    {
        $__internal_c195ce0c8fcff9b416c72044b9f065478422ec8bc92a266bf2979857cccae9d5 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c195ce0c8fcff9b416c72044b9f065478422ec8bc92a266bf2979857cccae9d5->enter($__internal_c195ce0c8fcff9b416c72044b9f065478422ec8bc92a266bf2979857cccae9d5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_d6278b74c7e2ef62a797b6c270ca9242c084c796c5b89440cd8b12169e9434b4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d6278b74c7e2ef62a797b6c270ca9242c084c796c5b89440cd8b12169e9434b4->enter($__internal_d6278b74c7e2ef62a797b6c270ca9242c084c796c5b89440cd8b12169e9434b4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 42
        echo "        <div class=\"row\">
            <div id=\"main\" class=\"col-sm-9\">
                ";
        // line 44
        $this->displayBlock('main', $context, $blocks);
        // line 45
        echo "            </div>
        </div>
    ";
        
        $__internal_d6278b74c7e2ef62a797b6c270ca9242c084c796c5b89440cd8b12169e9434b4->leave($__internal_d6278b74c7e2ef62a797b6c270ca9242c084c796c5b89440cd8b12169e9434b4_prof);

        
        $__internal_c195ce0c8fcff9b416c72044b9f065478422ec8bc92a266bf2979857cccae9d5->leave($__internal_c195ce0c8fcff9b416c72044b9f065478422ec8bc92a266bf2979857cccae9d5_prof);

    }

    // line 44
    public function block_main($context, array $blocks = array())
    {
        $__internal_fea86850081ac220cf481102344b9f181625ac039c4d1f5e0a23a157cf6b6008 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_fea86850081ac220cf481102344b9f181625ac039c4d1f5e0a23a157cf6b6008->enter($__internal_fea86850081ac220cf481102344b9f181625ac039c4d1f5e0a23a157cf6b6008_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        $__internal_c0d18fd4113819ff1854e03fe91267a828d508eef96e1c4e0a58a11ea1a7633f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c0d18fd4113819ff1854e03fe91267a828d508eef96e1c4e0a58a11ea1a7633f->enter($__internal_c0d18fd4113819ff1854e03fe91267a828d508eef96e1c4e0a58a11ea1a7633f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        
        $__internal_c0d18fd4113819ff1854e03fe91267a828d508eef96e1c4e0a58a11ea1a7633f->leave($__internal_c0d18fd4113819ff1854e03fe91267a828d508eef96e1c4e0a58a11ea1a7633f_prof);

        
        $__internal_fea86850081ac220cf481102344b9f181625ac039c4d1f5e0a23a157cf6b6008->leave($__internal_fea86850081ac220cf481102344b9f181625ac039c4d1f5e0a23a157cf6b6008_prof);

    }

    // line 50
    public function block_footer($context, array $blocks = array())
    {
        $__internal_bd78d49f654bc136c6e46f36d34a9ade26627055b4b1aead37a6244867734081 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_bd78d49f654bc136c6e46f36d34a9ade26627055b4b1aead37a6244867734081->enter($__internal_bd78d49f654bc136c6e46f36d34a9ade26627055b4b1aead37a6244867734081_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "footer"));

        $__internal_9e5322e5d366ebcde89b8960f983ad86ead7bcbcfe83d339a3e9d86bdc9a17be = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9e5322e5d366ebcde89b8960f983ad86ead7bcbcfe83d339a3e9d86bdc9a17be->enter($__internal_9e5322e5d366ebcde89b8960f983ad86ead7bcbcfe83d339a3e9d86bdc9a17be_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "footer"));

        // line 51
        echo "    <footer>
        <div class=\"container modal-footer\">
            <p>&copy; 2018 - Software University Foundation</p>
        </div>
    </footer>
";
        
        $__internal_9e5322e5d366ebcde89b8960f983ad86ead7bcbcfe83d339a3e9d86bdc9a17be->leave($__internal_9e5322e5d366ebcde89b8960f983ad86ead7bcbcfe83d339a3e9d86bdc9a17be_prof);

        
        $__internal_bd78d49f654bc136c6e46f36d34a9ade26627055b4b1aead37a6244867734081->leave($__internal_bd78d49f654bc136c6e46f36d34a9ade26627055b4b1aead37a6244867734081_prof);

    }

    // line 58
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_dd40ca06bfaef8464c3bab579d813a1fa2b6399a0302ffc6ca04b09e53dc37b8 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_dd40ca06bfaef8464c3bab579d813a1fa2b6399a0302ffc6ca04b09e53dc37b8->enter($__internal_dd40ca06bfaef8464c3bab579d813a1fa2b6399a0302ffc6ca04b09e53dc37b8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_f2cf962d684fb7a0d48e030c726bbbca9d9ba5993addd0f4776754118a1a6100 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f2cf962d684fb7a0d48e030c726bbbca9d9ba5993addd0f4776754118a1a6100->enter($__internal_f2cf962d684fb7a0d48e030c726bbbca9d9ba5993addd0f4776754118a1a6100_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 59
        echo "    <script src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/jquery-2.2.4.min.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 60
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/moment.min.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 61
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/bootstrap.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 62
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/bootstrap-datetimepicker.min.js"), "html", null, true);
        echo "\"></script>
";
        
        $__internal_f2cf962d684fb7a0d48e030c726bbbca9d9ba5993addd0f4776754118a1a6100->leave($__internal_f2cf962d684fb7a0d48e030c726bbbca9d9ba5993addd0f4776754118a1a6100_prof);

        
        $__internal_dd40ca06bfaef8464c3bab579d813a1fa2b6399a0302ffc6ca04b09e53dc37b8->leave($__internal_dd40ca06bfaef8464c3bab579d813a1fa2b6399a0302ffc6ca04b09e53dc37b8_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  279 => 62,  275 => 61,  271 => 60,  266 => 59,  257 => 58,  242 => 51,  233 => 50,  216 => 44,  204 => 45,  202 => 44,  198 => 42,  189 => 41,  166 => 26,  160 => 22,  151 => 21,  134 => 19,  122 => 14,  117 => 13,  108 => 12,  90 => 11,  77 => 64,  75 => 58,  72 => 57,  70 => 50,  66 => 48,  64 => 41,  60 => 39,  58 => 21,  53 => 19,  46 => 16,  44 => 12,  40 => 11,  33 => 6,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{#
   This is the base template used as the application layout which contains the
   common elements and decorates all the other templates.
   See http://symfony.com/doc/current/book/templating.html#template-inheritance-and-layouts
#}
<!DOCTYPE html>
<html lang=\"en-US\">
<head>
    <meta charset=\"UTF-8\"/>
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\"/>
    <title>{% block title %}Calculator{% endblock %}</title>
    {% block stylesheets %}
        <link rel=\"stylesheet\" href=\"{{ asset('css/style.css') }}\">
        <link rel=\"stylesheet\" href=\"{{ asset('css/bootstrap-datetimepicker.min.css') }}\">
    {% endblock %}
    <link rel=\"icon\" type=\"image/x-icon\" href=\"{{ asset('favicon.ico') }}\"/>
</head>

<body id=\"{% block body_id %}{% endblock %}\">

{% block header %}
    <header>
        <div class=\"navbar navbar-default navbar-static-top\" role=\"navigation\">
            <div class=\"container\">
                <div class=\"navbar-header\">
                    <a href=\"{{ path('index') }}\" class=\"navbar-brand\">CALCULATOR</a>

                    <button type=\"button\" class=\"navbar-toggle\" data-toggle=\"collapse\" data-target=\".navbar-collapse\">
                        <span class=\"icon-bar\"></span>
                        <span class=\"icon-bar\"></span>
                        <span class=\"icon-bar\"></span>
                    </button>
                </div>

            </div>
        </div>
    </header>
{% endblock %}

<div class=\"container body-container\">
    {% block body %}
        <div class=\"row\">
            <div id=\"main\" class=\"col-sm-9\">
                {% block main %}{% endblock %}
            </div>
        </div>
    {% endblock %}
</div>

{% block footer %}
    <footer>
        <div class=\"container modal-footer\">
            <p>&copy; 2018 - Software University Foundation</p>
        </div>
    </footer>
{% endblock %}

{% block javascripts %}
    <script src=\"{{ asset('js/jquery-2.2.4.min.js') }}\"></script>
    <script src=\"{{ asset('js/moment.min.js') }}\"></script>
    <script src=\"{{ asset('js/bootstrap.js') }}\"></script>
    <script src=\"{{ asset('js/bootstrap-datetimepicker.min.js') }}\"></script>
{% endblock %}

</body>
</html>
", "base.html.twig", "C:\\Calculator\\app\\Resources\\views\\base.html.twig");
    }
}
