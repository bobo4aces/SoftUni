<?php

/* @WebProfiler/Collector/router.html.twig */
class __TwigTemplate_d496044effa4cc39ce51801babe801f9942ccc5fec27a124c696ada197249fa7 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_18d4ba75a7a90012446792fd458bbaf38a8f9c0426c1b1110be32d0c1d1b677a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_18d4ba75a7a90012446792fd458bbaf38a8f9c0426c1b1110be32d0c1d1b677a->enter($__internal_18d4ba75a7a90012446792fd458bbaf38a8f9c0426c1b1110be32d0c1d1b677a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $__internal_4f1ca578ce975af89d50300001eef1daddfb0cefe56d3f93f295f587e0488b38 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4f1ca578ce975af89d50300001eef1daddfb0cefe56d3f93f295f587e0488b38->enter($__internal_4f1ca578ce975af89d50300001eef1daddfb0cefe56d3f93f295f587e0488b38_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_18d4ba75a7a90012446792fd458bbaf38a8f9c0426c1b1110be32d0c1d1b677a->leave($__internal_18d4ba75a7a90012446792fd458bbaf38a8f9c0426c1b1110be32d0c1d1b677a_prof);

        
        $__internal_4f1ca578ce975af89d50300001eef1daddfb0cefe56d3f93f295f587e0488b38->leave($__internal_4f1ca578ce975af89d50300001eef1daddfb0cefe56d3f93f295f587e0488b38_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_36de72703e2005f9e50e6b86e884f4768354c607c397a25a7abb9819002679b1 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_36de72703e2005f9e50e6b86e884f4768354c607c397a25a7abb9819002679b1->enter($__internal_36de72703e2005f9e50e6b86e884f4768354c607c397a25a7abb9819002679b1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        $__internal_85754f3a2f4dbd852e3776e4fc49f9f4d3f25f2a1df87d6ac2f9db91708ec23d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_85754f3a2f4dbd852e3776e4fc49f9f4d3f25f2a1df87d6ac2f9db91708ec23d->enter($__internal_85754f3a2f4dbd852e3776e4fc49f9f4d3f25f2a1df87d6ac2f9db91708ec23d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_85754f3a2f4dbd852e3776e4fc49f9f4d3f25f2a1df87d6ac2f9db91708ec23d->leave($__internal_85754f3a2f4dbd852e3776e4fc49f9f4d3f25f2a1df87d6ac2f9db91708ec23d_prof);

        
        $__internal_36de72703e2005f9e50e6b86e884f4768354c607c397a25a7abb9819002679b1->leave($__internal_36de72703e2005f9e50e6b86e884f4768354c607c397a25a7abb9819002679b1_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_31b0b0e8ac227ddb9907d18c522b33a020e6a0276884185f0536a19742b148ea = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_31b0b0e8ac227ddb9907d18c522b33a020e6a0276884185f0536a19742b148ea->enter($__internal_31b0b0e8ac227ddb9907d18c522b33a020e6a0276884185f0536a19742b148ea_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_7bd6eb683bcacc05bcd7e2a63ae80fcdc6855d255ec9664e99fb84f6eda17398 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7bd6eb683bcacc05bcd7e2a63ae80fcdc6855d255ec9664e99fb84f6eda17398->enter($__internal_7bd6eb683bcacc05bcd7e2a63ae80fcdc6855d255ec9664e99fb84f6eda17398_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_7bd6eb683bcacc05bcd7e2a63ae80fcdc6855d255ec9664e99fb84f6eda17398->leave($__internal_7bd6eb683bcacc05bcd7e2a63ae80fcdc6855d255ec9664e99fb84f6eda17398_prof);

        
        $__internal_31b0b0e8ac227ddb9907d18c522b33a020e6a0276884185f0536a19742b148ea->leave($__internal_31b0b0e8ac227ddb9907d18c522b33a020e6a0276884185f0536a19742b148ea_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_35fe133c919a8afa9b13e0543dd0f8ff32b2c5b4d500f805a958d7f235c95087 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_35fe133c919a8afa9b13e0543dd0f8ff32b2c5b4d500f805a958d7f235c95087->enter($__internal_35fe133c919a8afa9b13e0543dd0f8ff32b2c5b4d500f805a958d7f235c95087_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_90b7266ff3af95297b7dab1295e4bc30e98cd29f09167e4a9a3cc2f03c97b6bd = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_90b7266ff3af95297b7dab1295e4bc30e98cd29f09167e4a9a3cc2f03c97b6bd->enter($__internal_90b7266ff3af95297b7dab1295e4bc30e98cd29f09167e4a9a3cc2f03c97b6bd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_router", array("token" => ($context["token"] ?? $this->getContext($context, "token")))));
        echo "
";
        
        $__internal_90b7266ff3af95297b7dab1295e4bc30e98cd29f09167e4a9a3cc2f03c97b6bd->leave($__internal_90b7266ff3af95297b7dab1295e4bc30e98cd29f09167e4a9a3cc2f03c97b6bd_prof);

        
        $__internal_35fe133c919a8afa9b13e0543dd0f8ff32b2c5b4d500f805a958d7f235c95087->leave($__internal_35fe133c919a8afa9b13e0543dd0f8ff32b2c5b4d500f805a958d7f235c95087_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  94 => 13,  85 => 12,  71 => 7,  68 => 6,  59 => 5,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block toolbar %}{% endblock %}

{% block menu %}
<span class=\"label\">
    <span class=\"icon\">{{ include('@WebProfiler/Icon/router.svg') }}</span>
    <strong>Routing</strong>
</span>
{% endblock %}

{% block panel %}
    {{ render(path('_profiler_router', { token: token })) }}
{% endblock %}
", "@WebProfiler/Collector/router.html.twig", "C:\\Calculator\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Collector\\router.html.twig");
    }
}
